from connection import connect_to_db, close_connection

from utils import put_object_in_bucket, query_updated_table_information, get_datestamp_from_table, get_current_timestamp, put_timestamp_in_s3

def ingestion_lambda_handler(event, context):

    conn = connect_to_db()

    table_names = [
            'sales_order',
            'design',
            'currency',
            'staff',
            'counterparty',
            'address',
            'department',
            'purchase_order',
            'payment_type',
            'payment',
            'transaction'
            ]
    
    dt = get_current_timestamp()

    for table in table_names:
        individual_table = query_updated_table_information(conn, table, dt)
        #think about empty data
        # put_object_in_bucket(table, individual_table) 
        #empty timestamp 

        

        potential_timestamp = get_datestamp_from_table(individual_table, table)
        
        if individual_table[table][-1]['last_updated'] > potential_timestamp:
            potential_timestamp = individual_table[table][-1]['last_updated']
    
    put_timestamp_in_s3(potential_timestamp)
    
    close_connection(conn=conn)

    return potential_timestamp
event = {}
context = []
print(ingestion_lambda_handler(event=event, context=context))
print(ingestion_lambda_handler(event=event, context=context))
print(ingestion_lambda_handler(event=event, context=context))